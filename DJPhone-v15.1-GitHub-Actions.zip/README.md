# DJPhone v15.1 - Production-Hardened iOS Client for DJI 1st Gen 4G Module

## Key Fixes & Architecture Upgrades in v15.1:
1. **Dedicated `AT+CGMR` Barrier Probe, Single-Decrement Counting & 30s Orphan Expiry (Fixes Bug 1 & Bug 2)**:
   - Uses `AT+CGMR` as the barrier probe (never used by periodic status polling) so a late `+CSQ:` from a timed-out status poll never triggers orphan probe absorption or swallows `ATH`'s `OK`.
   - Decrements `unansweredBarrierProbeCount` only once per probe inside the barrier (on the `+CGMR:` / `EG25...` data line, without double-decrementing on its trailing `OK`).
   - Resets `unansweredOrphanProbesSent` on every `enterSyncBarrier()` and expires it after 30.0s.
2. **Lock-Screen-Writable Session Fallback Store (`.completeFileProtectionUntilFirstUserAuthentication`) (Fixes Bug 3)**:
   - Writes `djphone_sms_session_fallback.json` with `.completeFileProtectionUntilFirstUserAuthentication` so messages arriving while locked are persisted to disk immediately.
3. **Unlocked Main Store Corruption Self-Healing & Deduplicated Read-Only Fallback (Fixes Bug 4 & Bug 6)**:
   - When `isProtectedDataAvailable == true` (device unlocked) and both `djphone_sms_store.json` and backups fail to decode, quarantines the corrupted files to `.corrupt` and rebuilds the main store immediately (`loadFailedReadOnlyGuard = false`).
   - Deduplicates and caps messages at `maxCount` (500) before returning in the locked read-only fallback path.
4. **Two-Generation N-1 (`.bak`) & N-2 (`.bak2`) Backup Rotation with Change Check (Fixes Bug 5)**:
   - Rotates `.bak -> .bak2` and `canonical -> .bak` only when `prevItems != messages`, and supports recovery from `.bak2`.
5. **CI Stale-Version Check & 22-Suite Automated Test Runner (Fixes Bug 7)**:
   - Added explicit stale-version header verification step in `.github/workflows/build-ipa.yml` alongside `PASSED_COUNT >= 22` and mandatory title checks.
